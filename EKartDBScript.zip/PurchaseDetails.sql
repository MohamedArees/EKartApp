USE [EKartDb]
GO

INSERT INTO [dbo].[PurchaseDetails]([EmailId],[ProductId],[QuantityPurchased])VALUES('james@gmail.com',21,2)
INSERT INTO [dbo].[PurchaseDetails]([EmailId],[ProductId],[QuantityPurchased])VALUES('james@gmail.com',22,3)
INSERT INTO [dbo].[PurchaseDetails]([EmailId],[ProductId],[QuantityPurchased])VALUES('alex@gmail.com',21,1)
INSERT INTO [dbo].[PurchaseDetails]([EmailId],[ProductId],[QuantityPurchased])VALUES('ronaldo@gmail.com',24,2)
INSERT INTO [dbo].[PurchaseDetails]([EmailId],[ProductId],[QuantityPurchased])VALUES('sam@gmail.com',22,3)
INSERT INTO [dbo].[PurchaseDetails]([EmailId],[ProductId],[QuantityPurchased])VALUES('tom@gmail.com',23,1)
Go


