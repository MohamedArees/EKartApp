USE [EKartDb]
GO

INSERT INTO [dbo].[Users]
           ([EmailId]
           ,[RoleId]
           ,[UserName]
           ,[Gender]
           ,[Address]
           ,[Phone])
     VALUES
           ('machinetest265@gmail.com',1,'Admin User','M','India',8838388989)
GO


