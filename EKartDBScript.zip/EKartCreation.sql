IF OBJECT_ID('Users') IS NOT NULL
DROP TABLE Users
GO

IF OBJECT_ID('Roles') IS NOT NULL
DROP TABLE Roles
GO

IF OBJECT_ID('Products') IS NOT NULL
DROP TABLE Products
GO

IF OBJECT_ID('PurchaseDetails') IS NOT NULL
DROP TABLE PurchaseDetails
GO


Create table Roles
(
	[RoleId] Tinyint constraint pk_RoleId Primary key Identity,
	[RoleName] varchar(10) constraint uq_RoleName Unique
)
Go
Create table Users
(
	[EmailId] varchar(40) constraint pk_EmailId Primary key,
	[RoleId] Tinyint constraint fk_RoleId References Roles(RoleId),
	[UserName] varchar(30) not null,
	[Gender] char constraint chk_Gender check(Gender='F' or Gender='M'),
	[Address] varchar(200),
	[Phone] numeric(10)
)
Go
Create table Products
(
[ProductId] Tinyint constraint pk_ProductId Primary Key Identity,
[ProductName] Varchar(30) constraint uq_ProductName Unique Not null,
[Price] Numeric(10,2) constraint chk_Price Check(Price>0) Not null,
[QuantityAvailable] Int constraint chk_QuantityAvaialbe Check(QuantityAvailable > 0) Not Null,
[ProductImageUrl] Varchar(40) Not null,
)
Go
Create table PurchaseDetails
(
[PurchaseId] Bigint constraint pk_PurchaseId Primary key Identity(1000,1),
[EmailId] Varchar(40) constraint fk_EmailId References Users(EmailId),
[ProductId] Tinyint constraint fk_ProductId References Products(ProductID),
[QuantityPurchased] Int constraint chk_QuantityPurchased Check(QuantityPurchased > 0) Not Null,
[DateOfPurchase] Datetime constraint chk_DateOfPurchase check(DateOfPurchase<=getdate()) Default getdate() Not null
)
Go