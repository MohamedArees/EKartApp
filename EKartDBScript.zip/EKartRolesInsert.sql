USE [EKartDb]
GO

INSERT INTO [dbo].[Roles]
           ([RoleName])
     VALUES
           ('User')
GO


INSERT INTO [dbo].[Roles]
           ([RoleName])
     VALUES
           ('Admin')
GO