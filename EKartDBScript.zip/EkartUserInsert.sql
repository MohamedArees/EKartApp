USE [EKartDb]
GO

INSERT INTO [dbo].[Users]
([EmailId],[RoleId],[UserName],[Gender],[Address],[Phone])VALUES('jhon@gmail.com',2,'Jhon','M' ,'India' ,9999999999)

INSERT INTO [dbo].[Users]
([EmailId],[RoleId],[UserName],[Gender],[Address],[Phone])VALUES('sam@gmail.com',2,'Sam','M' ,'India' ,9999999999)

INSERT INTO [dbo].[Users]
([EmailId],[RoleId],[UserName],[Gender],[Address],[Phone])VALUES('tom@gmail.com',2,'Tom','M' ,'India' ,9999999999)

INSERT INTO [dbo].[Users]
([EmailId],[RoleId],[UserName],[Gender],[Address],[Phone])VALUES('alex@gmail.com',2,'Alex','M' ,'India' ,9999999999)

INSERT INTO [dbo].[Users]
([EmailId],[RoleId],[UserName],[Gender],[Address],[Phone])VALUES('raja@gmail.com',2,'Raja','M' ,'India' ,9999999999)

INSERT INTO [dbo].[Users]
([EmailId],[RoleId],[UserName],[Gender],[Address],[Phone])VALUES('roja@gmail.com',2,'Roja','F','India' ,9999999999)

INSERT INTO [dbo].[Users]
([EmailId],[RoleId],[UserName],[Gender],[Address],[Phone])VALUES('sara@gmail.com',2,'Sara','F' ,'India' ,9999999999)

INSERT INTO [dbo].[Users]
([EmailId],[RoleId],[UserName],[Gender],[Address],[Phone])VALUES('james@gmail.com',2,'James','M' ,'India' ,9999999999)

INSERT INTO [dbo].[Users]
([EmailId],[RoleId],[UserName],[Gender],[Address],[Phone])VALUES('ronaldo@gmail.com',2,'Ronaldo','M' ,'India' ,9999999999)

INSERT INTO [dbo].[Users]
([EmailId],[RoleId],[UserName],[Gender],[Address],[Phone])VALUES('alexa@gmail.com',2,'Alexa','F' ,'India' ,9999999999)

INSERT INTO [dbo].[Users]
([EmailId],[RoleId],[UserName],[Gender],[Address],[Phone])VALUES('jhon@gmail.com',2,'jhon','M' ,'India' ,9999999999)


GO


