USE [EKartDb]
GO

INSERT INTO [dbo].[Products] ([ProductName],[Price],[QuantityAvailable],[ProductImageUrl])VALUES
('Earphone',300,40,'G:\Screenshot (1).png')

INSERT INTO [dbo].[Products] ([ProductName],[Price],[QuantityAvailable],[ProductImageUrl])VALUES('Charger',140,10,'G:\Screenshot (2).png')
INSERT INTO [dbo].[Products] ([ProductName],[Price],[QuantityAvailable],[ProductImageUrl])VALUES('Redmi Watch',2500.50,40,'G:\Screenshot (1).png')
INSERT INTO [dbo].[Products] ([ProductName],[Price],[QuantityAvailable],[ProductImageUrl])VALUES('Toy',45.55,30,'G:\Screenshot (4).png')
INSERT INTO [dbo].[Products] ([ProductName],[Price],[QuantityAvailable],[ProductImageUrl])VALUES('Key Chain',30,45,'G:\Screenshot (5).png')
INSERT INTO [dbo].[Products] ([ProductName],[Price],[QuantityAvailable],[ProductImageUrl])VALUES('Alexa',453.50,4,'G:\Screenshot (6).png')

GO


