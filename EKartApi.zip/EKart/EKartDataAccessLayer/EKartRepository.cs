﻿using EKartDataAccessLayer.Models;
using System;
using System.Collections.Generic;
using System.Linq;
namespace EKartDataAccessLayer
{
    public class EKartRepository
    {
        EKartDbContext context;
        public EKartRepository()
        {
            context = new EKartDbContext();
        }

        public List<User> GetAllUsers()
        {
            try
            {
                var usersList = (from user in context.Users orderby user.EmailId select user).ToList();
                return usersList;
            }
            catch (Exception ex) 
            {
                return null;
            }

        }
        public User GetUserByEmailId(string emailId)
        {
            User userData = null;
            try
            {
                userData = context.Users.Where(usr => usr.EmailId == emailId).FirstOrDefault();
                return userData;
            }
            catch (Exception ex)
            {
                return null;
            }

        }

        public bool AddUserByEmailId(User userAddData)
        {
            User userData = null;
            try
            {
                userData = context.Users.Find(userAddData.EmailId);
                if (userData == null)
                {
                    context.Users.Add(userAddData);
                    context.SaveChanges();
                    return true;
                }
                return false;
            }
            catch
            {
                return false;
            }
        }

        public List<Product> GetAllProducts()
        {
            try
            {
                var productList = (from product in context.Products orderby product.ProductId select product).ToList();
                return productList;
            }
            catch (Exception ex)
            {
                return null;
            }
        }

        public Product GetProductByProductId(int productId)
        {
            Product productData = null;
            try
            {
                productData = context.Products.Find(productId);
                return productData;
            }
            catch (Exception ex)
            {
                return null;
            }
        }

        public string UpdateProductByProductId(int productId, Product prd )
        {
            Product productData = null;
            try
            {
                if (prd != null)
                {
                    productData = context.Products.Find(productId);
                    productData.Price = prd.Price;
                    if (productData.QuantityAvailable - prd.QuantityAvailable >= 0)
                    {
                        productData.QuantityAvailable = prd.QuantityAvailable;
                    }
                    else
                    {
                        return "ProductQuantityNotAvailable";
                    }
                    using (var newContext = new EKartDbContext())
                    {
                        newContext.Products.Update(productData);
                        newContext.SaveChanges();
                    }
                    return "Success";
                }
                else
                {
                    return "ProductNotAvailable";
                }
            }
            catch(Exception ex)
            {
                return ex.Message;
            }

        }

        public string AddProduct(Product product)
        {
            Product productData = null;
            try {
                productData = context.Products.Find(product.ProductName);
                if (productData != null)
                {
                    return "DuplicateProductName";
                }
                else
                {
                    productData.ProductImageUrl = product.ProductImageUrl;
                    productData.Price = product.Price;
                    productData.QuantityAvailable = product.QuantityAvailable;
                    productData.ProductName = product.ProductName;
                    context.Products.Add(productData);
                    context.SaveChanges();
                    return "Success";
                }
            }
            catch (Exception ex)
            {
                return ex.Message;
            }
            
        }


        public bool DeleteProductByProductId(int productId)
        {
            Product productData = null;
            try
            {
                productData = context.Products.Find(productId);
                if (productData != null)
                {
                    context.Products.Remove(productData);
                    context.SaveChanges();
                    return true;
                }
                else {
                    return false;
                }
               
            }
            catch (Exception ex)
            {
                return false;
            }
        }

        public List<PurchaseDetail> GetAllPurchaseDetail(string emailId)
        {
            try
            {
                var purchaseDetailList = context.PurchaseDetails.Where(usr => usr.EmailId == emailId).ToList();
                return purchaseDetailList;
            }
            catch (Exception ex)
            {
                return null;
            }
        }

    }

}
