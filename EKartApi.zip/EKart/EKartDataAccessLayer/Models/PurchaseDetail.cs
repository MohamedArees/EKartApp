﻿using System;
using System.Collections.Generic;
using System.Runtime.Serialization;
using System.Text;

namespace EKartDataAccessLayer.Models
{
    public partial class PurchaseDetail
    {
        [DataMember]
        public long PurchaseId { get; set; }
        [DataMember]
        public string EmailId { get; set; }
        [DataMember]
        public byte? ProductId { get; set; }
        [DataMember]
        public int QuantityPurchased { get; set; }
        [DataMember]
        public DateTime DateOfPurchase { get; set; }
        [DataMember]
        public virtual User Email { get; set; }
        [DataMember]
        public virtual Product Product { get; set; }
    }
}
