﻿using System;
using System.Collections.Generic;

#nullable disable

namespace EKartDataAccessLayer.Models
{
    public partial class User
    {
        public User()
        {
            PurchaseDetails = new HashSet<PurchaseDetail>();
        }

        public string EmailId { get; set; }
        public byte? RoleId { get; set; }
        public string UserName { get; set; }
        public string Gender { get; set; }
        public string Address { get; set; }
        public decimal? Phone { get; set; }

        public virtual Role Role { get; set; }
        public virtual ICollection<PurchaseDetail> PurchaseDetails { get; set; }
    }
}
