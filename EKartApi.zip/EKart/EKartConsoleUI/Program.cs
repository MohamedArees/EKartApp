﻿using EKartDataAccessLayer;
using EKartBusinessProcessLayer;
using System;

namespace EKartConsoleUI
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Hello World!");
            //EKartRepository eKartObj = new EKartRepository();
            ////var userList = eKartObj.GetAllUsers();
            ////foreach (var user in userList)
            ////{
            ////    Console.WriteLine(user.EmailId);
            ////}
            //var data = eKartObj.AddUserByEmailId("tat.com");
            //if(data)
            //{
            //    var dat = eKartObj.GetUserByEmailId("tat.com");
            //    Console.WriteLine(dat.EmailId);
            UserBL eKart = new UserBL();
            var userList = eKart.GetAllUser();
            foreach (var user in userList)
            {
                Console.WriteLine(user.EmailId);
            }
              
        }
    }
}
