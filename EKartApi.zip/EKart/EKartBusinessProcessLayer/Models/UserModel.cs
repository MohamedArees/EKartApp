﻿using System;
using System.Collections.Generic;
using System.Runtime.Serialization;
using System.Text;

namespace EKartBusinessProcessLayer.Models
{
    public class UserModel
    {
        [DataMember]
        public string EmailId { get; set; }
        [DataMember]
        public string UserName { get; set; }
        [DataMember]
        public string Gender { get; set; }
        [DataMember]
        public string Address { get; set; }
        [DataMember]
        public decimal? Phone { get; set; }
        [DataMember]
        public byte? RoleId { get; set; }
    }
}
