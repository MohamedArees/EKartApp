﻿using System;
using System.Collections.Generic;
using System.Runtime.Serialization;
using System.Text;
namespace EKartBusinessProcessLayer.Models
{
    public class PurchaseDetailModel
    {
        [DataMember]
        public long PurchaseId { get; set; }
        [DataMember]
        public string EmailId { get; set; }
        [DataMember]
        public byte? ProductId { get; set; }
        [DataMember]
        public int QuantityPurchased { get; set; }
        [DataMember]
        public DateTime DateOfPurchase { get; set; }
        [DataMember]
        public UserModel Email { get; set; }
        [DataMember]
        public ProductModel Product { get; set; }
    }
}
