﻿using System;
using System.Collections.Generic;
using System.Runtime.Serialization;
using System.Text;

namespace EKartBusinessProcessLayer.Models
{
    public class RoleModel
    {
        [DataMember]
        public byte RoleId { get; set; }
        [DataMember]
        public string RoleName { get; set; }
    }
}
