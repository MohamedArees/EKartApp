﻿using System;
using System.Collections.Generic;
using System.Text;

namespace EKartBusinessProcessLayer.Models
{
    public class ProductModel
    {
        public byte ProductId { get; set; }
        public string ProductName { get; set; }
        public decimal Price { get; set; }
        public int QuantityAvailable { get; set; }
        public string ProductImageUrl { get; set; }
    }
}
