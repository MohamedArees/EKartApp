﻿using System;
using EKartDataAccessLayer;
using System.Collections.Generic;
using EKartBusinessProcessLayer.Models;
using EKartDataAccessLayer.Models;

namespace EKartBusinessProcessLayer
{
    public class UserBL
    {
        EKartRepository repository;
        public UserBL()
        {
            repository = new EKartRepository();
        }

        public List<UserModel> GetAllUser()
        {
            List<UserModel> userDataList;
            try
            {
                userDataList = new List<UserModel>();
                List<User> userList = repository.GetAllUsers();
                foreach (var user in userList)
                {
                    UserModel userData = new UserModel();
                    userData.Address = user.Address;
                    userData.EmailId = user.EmailId;
                    userData.Gender = user.Gender;
                    userData.Phone = user.Phone;
                    userData.UserName = user.UserName;
                    userData.RoleId = user.RoleId;
                    userDataList.Add(userData);
                }
                return userDataList;
            }
            catch (Exception ex)
            {
                return null;
            }
        }

        public bool AddUser(UserModel user)
        {
            bool status = false;
            User userDbData;
            try
            {
                if (user != null)
                {
                    userDbData = new User();
                    userDbData.Address = user.Address;
                    userDbData.EmailId = user.EmailId;
                    userDbData.Gender = user.Gender;
                    userDbData.Phone = user.Phone;
                    userDbData.RoleId = user.RoleId;
                    userDbData.UserName = user.UserName;
                    status = repository.AddUserByEmailId(userDbData);
                    return status;
                }
                else {
                    return status;
                }
            }
            catch (Exception ex)
            {
                return status;
            }
        }
    }
}
