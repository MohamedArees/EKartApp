﻿using System;
using EKartDataAccessLayer;
using System.Collections.Generic;
using EKartBusinessProcessLayer.Models;
using EKartDataAccessLayer.Models;

namespace EKartBusinessProcessLayer
{
    public class ProductBL
    {
        EKartRepository repository;
        public ProductBL()
        {
            repository = new EKartRepository();
        }
        public List<ProductModel> GetAllProducts()
        {
            List<ProductModel> productDataList;
            try
            {
                productDataList = new List<ProductModel>();
                List<Product> prductList = repository.GetAllProducts();
                foreach (var product in prductList)
                {
                    ProductModel productData = new ProductModel();
                    productData.ProductImageUrl = product.ProductImageUrl;
                    productData.ProductName = product.ProductName;
                    productData.Price = product.Price;
                    productData.QuantityAvailable = product.QuantityAvailable;
                    productData.ProductId = product.ProductId;
                    productDataList.Add(productData);
                }
                return productDataList;
            }
            catch (Exception ex)
            {
                return null;
            }
        }

        public ProductModel GetProductById(int producrId)
        {
            ProductModel productData;
            try
            {
                productData = new ProductModel();
                Product product = repository.GetProductByProductId(producrId);
                productData.ProductImageUrl = product.ProductImageUrl;
                productData.ProductName = product.ProductName;
                productData.Price = product.Price;
                productData.QuantityAvailable = product.QuantityAvailable;
                productData.ProductId = product.ProductId;
                return productData; 
            }
            catch (Exception ex)
            {
                return null;
            }
        }

        public string AddPRoduct(ProductModel product)
        {
            string status = "IssueWithUIData";
            Product productData;
            try {
                if (product != null)
                {
                    productData = new Product();
                    productData.Price = product.Price;
                    productData.ProductImageUrl = product.ProductImageUrl;
                    productData.ProductName = product.ProductName;
                    productData.QuantityAvailable = product.QuantityAvailable;
                    status = repository.AddProduct(productData);
                    return status;
                }
                else { 
                    return status;
                }
            }
            catch (Exception ex)
            {
                return ex.Message;
            }
        }

        public string updatePrioductById(ProductModel product)
        {
            string status = "IssueWithUIData";
            Product productData;
            try
            {
                if (product != null)
                {
                   
                    productData = new Product();
                    productData.Price = product.Price;
                    productData.ProductImageUrl = product.ProductImageUrl;
                    productData.ProductName = product.ProductName;
                    productData.QuantityAvailable = product.QuantityAvailable;
                    status = repository.UpdateProductByProductId(productData.ProductId,productData);
                    return status;
                }
                else
                {
                    return status;
                }
            }
            catch (Exception ex)
            {
                return ex.Message;
            }
        }

        public bool deleteProductById(int producId)
        {
            bool status = false;
            try
            {
                status = repository.DeleteProductByProductId(producId);
                return status;
            }
            catch (Exception ex)
            {
                return status;
            }
        }
    }
}
