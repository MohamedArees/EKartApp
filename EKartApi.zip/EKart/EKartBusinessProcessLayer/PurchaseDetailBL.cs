﻿using System;
using EKartDataAccessLayer;
using System.Collections.Generic;
using EKartBusinessProcessLayer.Models;
using EKartDataAccessLayer.Models;

namespace EKartBusinessProcessLayer
{
    public class PurchaseDetailBL
    {
        EKartRepository repository;
        public PurchaseDetailBL()
        {
            repository = new EKartRepository();
        }

        public List<PurchaseDetailModel> GetAllPurchases(string emailId)
        {
            List<PurchaseDetailModel> purchaseDataList;
            try
            {
                purchaseDataList = new List<PurchaseDetailModel>();
                List<PurchaseDetail> purchaseList = repository.GetAllPurchaseDetail(emailId);
                foreach (var product in purchaseList)
                {
                    PurchaseDetailModel purchaseData = new PurchaseDetailModel();
                    purchaseData.QuantityPurchased = product.QuantityPurchased;
                    purchaseData.ProductId = product.ProductId;
                    purchaseData.EmailId = product.EmailId;
                    purchaseData.DateOfPurchase = product.DateOfPurchase;
                    purchaseData.PurchaseId = product.PurchaseId;
                    purchaseDataList.Add(purchaseData);
                }
                return purchaseDataList;
            }
            catch (Exception ex)
            {
                return null;
            }
        }
    }
}
