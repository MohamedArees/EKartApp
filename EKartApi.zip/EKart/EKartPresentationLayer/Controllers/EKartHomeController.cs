﻿using Microsoft.AspNetCore.Mvc;
using System;
using System.Collections.Generic;
using EKartBusinessProcessLayer;
using EKartBusinessProcessLayer.Models;
namespace EKartPresentationLayer.Controllers
{
    [Route("api/[controller]/[action]")]
    [ApiController]
    public class EKartHomeController : Controller
    {
        UserBL userBL;
        ProductBL productBL;
        RoleBL roleBL;
        PurchaseDetailBL purchaseDetailBL;

        public EKartHomeController()
        {
            userBL = new UserBL();
            productBL = new ProductBL();
            roleBL = new RoleBL();
            purchaseDetailBL = new PurchaseDetailBL();
        }
        
        [HttpGet]
        public JsonResult GetAllUsers()
        {
            List<UserModel> userList;
            try
            {
                userList = userBL.GetAllUser();
            }
            catch (Exception ex)
            {
                userList = null;
            }
            return Json(userList);
        }
        [HttpPut]
        public JsonResult AddUser([FromQuery]string EmailId, [FromBody] UserModel user)
        {
            UserModel userObj =new UserModel();
            bool status;
            try
            {
                userObj.RoleId = 2;
                userObj.Gender = "M";
                userObj.Address = "India";
                userObj.EmailId = EmailId;
                userObj.UserName = user.UserName;
                userObj.Phone = 9898989898;
                status = userBL.AddUser(userObj);
            }
            catch (Exception ex)
            {
                status = false;
            }
            return Json(status);
        }

        [HttpGet]
        public JsonResult GetAllProducts()
        {
            List<ProductModel> productList;
            try
            {
                productList = productBL.GetAllProducts();
            }
            catch (Exception ex)
            {
                productList = null;
            }
            return Json(productList);
        }

        [HttpGet]
        public JsonResult GetProduct([FromQuery] int prodcutId)
        {
            ProductModel product;
            try
            {
                product = productBL.GetProductById(15);
            }
            catch (Exception ex)
            {
                product = null;
            }
            return Json(product);
        }

        [HttpGet]
        public JsonResult GetAllPurchases([FromQuery] string emailId)
        {
            List<PurchaseDetailModel> purchaseLDetailsList;
            try {
                purchaseLDetailsList = purchaseDetailBL.GetAllPurchases(emailId);
            }
            catch (Exception ex)
            {
                purchaseLDetailsList = null;
            }
            return Json(purchaseLDetailsList);
        }

        [HttpPut]
        public JsonResult UpdateProduct([FromBody] ProductModel proObj)
        {
            try
            {
                string product = productBL.updatePrioductById(proObj);
                return Json(product);

            }
            catch (Exception ex)
            {
                return null;
            }
        }

        [HttpDelete]
        public JsonResult DeleteProduct([FromQuery] int prodcutId) {
            try
            {
                bool status = productBL.deleteProductById(prodcutId);
                return Json(status);
            }
            catch(Exception ex){
                return null;
            }
        }

    }
}
