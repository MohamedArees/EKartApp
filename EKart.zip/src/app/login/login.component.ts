import { Component, OnInit } from '@angular/core';
//login imports
import { SocialAuthService, GoogleLoginProvider, SocialUser } from 'angularx-social-login';
import { UserDetailsService } from 'src/services/user-details.service';






@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.scss']
})


export class LoginComponent implements OnInit {
  //Social User 
  user: SocialUser;
  userData:any=[];  
  //number  
  userRole:number;
  //boolean 
  viewProducts:boolean;
  viewPurchase:boolean;
  //emailId
  emailId:string;
  constructor(
    private authService: SocialAuthService,
    private userService:UserDetailsService,
    ) { }
  ngOnInit(): void {
    this.authService.authState.subscribe((user) => {
     
        this.user = user;
        
        if(this.user!=null)
        {
          this.emailId = this.user.email;
        this.addUser();
      }
    })
    this.viewProducts = false;
    this.viewPurchase = false;
  }

  signInWithGoogle(): any {
    this.authService.signIn(GoogleLoginProvider.PROVIDER_ID)
    this.viewProducts = false;
  }
  signOut(): any {
    this.authService.signOut();
    this.viewProducts = false;
  } 
  getUsers(userEmail)
  {
     this.userService.getAllUsers().subscribe( res =>
      {
        this.userData = res; 
        this.userRole =this.userData.userRole;
        for(let userDa of this.userData)
        {
            if(userDa.emailId == userEmail)
            {
              this.userRole = userDa.roleId;
            }
        }
      })
  }
  addUser()
  {
    this.userService.addUser(this.user.name,this.user.email).subscribe(res=>{
      this.getUsers(this.user.email);
    })
  }
  getAllProducts()
  {
    this.viewProducts = true;
    this.viewPurchase = false;
  }
  getAllPurchases()
  {
    this.viewProducts = false;
    this.viewPurchase = true;
  }
}