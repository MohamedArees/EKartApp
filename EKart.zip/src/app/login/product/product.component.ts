import { Component, Input, OnInit } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { ProductDetailsService } from 'src/services/product-details.service';
@Component(
	{
		selector: 'app-product',
		templateUrl: './product.component.html',
		styleUrls: ['./product.component.scss']
	})
export class ProductComponent implements OnInit {
	@Input() userRole: number;
	@Input() emailId: string;

	//any 
	products: any = [];
	responsiveOptions: any = [];
	productCart: any[] = [];
	addStatus: any;
	deleteStatus: any;
	updateStatus: any;
	//boolean
	newProductShow = false;
	checkOutShow = false;
	deletePopUpShow = false;
	//String
	imageSrc: "C:/Users/mohamed.y/Desktop/img.PNG";
	productName: string;

	//number
	productId: number;
	price = 0;

	constructor(private productService: ProductDetailsService, ) {
	}
	ngOnInit(): void {
		this.responsiveOptions = [
			{
				breakpoint: '1024px',
				numVisible: 3, numScroll: 3
			},
			{
				breakpoint: '768px',
				numVisible: 2,
				numScroll: 2
			}, {
				breakpoint: '560px',
				numVisible: 1, numScroll: 1
			}];
		this.getAllProducts();
	}
	getAllProducts() {
		this.productService.getAllProducts().subscribe(res => {
			this.products = res;
		});
	}
	checkOut() {
		this.checkOutShow = true;
		this.newProductShow = false;
	}
	addProduct(product) {
		let count = 0;
		if (this.productCart.length > 0) {
			for (let pro of this.productCart) {
				if (product.productId == pro.id) {
					pro.quantity += 1;
					break;
				}
				else {
					count += 1
				}
			}
			if (this.productCart.length == count) {
				let c = {
					"id": product.productId,
					"quantity": 1,
					"price": product.price,
					"name":product.productName,
				}
				this.productCart.push(c)
			}
		}
		else {
			let c = {
				"id": product.productId,
				"quantity": 1,
				"price": product.price,
				"name":product.productName,
			}
			this.productCart.push(c)
		}
		this.price += product.price
	}
	removeProduct(product) {
		if (this.productCart.length > 0) {
			for (let pro of this.productCart) 
			{
				if (product.productId == pro.id) {
					if (pro.quantity - 1 >= 0) {
						let v = this.productCart.indexOf(pro.id);
						this.productCart[v].quantity -= 1;
						this.price -= product.pice
						break;
					}
				}
			}
		}
	}
	updateProduct(productId) {

	}
	deleteProduct() {
		this.productService.deleteProduct(this.productId).subscribe(res => {
			this.deleteStatus = res;
		})
	}
	deleteShow(productId) {
		this.deletePopUpShow = true;
		this.productId = productId;
		this.newProductShow = false;
		this.checkOutShow = false;
	}
	addNewProduct() {
		this.newProductShow = true;
		this.checkOutShow = false;
		this.deletePopUpShow = false;
	}

	addNewProductByAdmin(productName) {
		this.productService.addProduct(productName).subscribe(
			res => {
				this.addStatus = res;
			}
		)
	}
	purchaseProduct(cart,emailId) {
		this.productService.purchaseProducts(emailId,cart).subscribe(
			res => {
				this.addStatus = res;
			})
	}
}