import { Component, OnInit, Input } from '@angular/core';
import { ProductDetailsService } from 'src/services/product-details.service';
@Component({
  selector: 'app-purchase',
  templateUrl: './purchase.component.html',
  styleUrls: ['./purchase.component.scss']
})
export class PurchaseComponent implements OnInit {
  @Input() userRole: number;
	@Input() emailId: string;
  responsiveOptions = [];
  purchases: any = [];
  constructor(private productService: ProductDetailsService) { }
  ngOnInit() {
    this.responsiveOptions = [
      {
        breakpoint: '1024px',
        numVisible: 3, numScroll: 3
      },
      {
        breakpoint: '768px',
        numVisible: 2,
        numScroll: 2
      }, {
        breakpoint: '560px',
        numVisible: 1, numScroll: 1
      }];
    this.getAllPurchases();
  }
  getAllPurchases() {
    this.productService.getAllPurchases(this.emailId).subscribe(res => {
      this.purchases = res;
    });
  }
}
