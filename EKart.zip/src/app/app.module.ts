import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import { HttpClientModule } from '@angular/common/http';
//imports for social login
import { SocialAuthServiceConfig } from 'angularx-social-login';
import { SocialLoginModule, GoogleLoginProvider } from 'angularx-social-login';
import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { from } from 'rxjs';
import { FormGroup, FormsModule,FormControl,ReactiveFormsModule,RequiredValidator } from '@angular/forms';
import { LoginComponent } from './login/login.component'; import { ProductComponent } from './login/product/product.component'; import { CarouselModule } from 'primeng-lts/carousel'; import { ButtonModule } from 'primeng-lts/button'; import { ToastModule } from 'primeng-lts/toast'; import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import { DialogModule } from 'primeng-lts/dialog';
import { PurchaseComponent } from './login/purchase/purchase.component';
@NgModule(
  {
    declarations:
      [AppComponent, LoginComponent, ProductComponent, PurchaseComponent],
    imports: [
      BrowserModule,
      AppRoutingModule,
      SocialLoginModule,
      HttpClientModule,
      CarouselModule,
      FormsModule,
      ButtonModule,
      ReactiveFormsModule,
      BrowserAnimationsModule,
      ToastModule,
      DialogModule
    ],
    providers: [
      {
        provide: 'SocialAuthServiceConfig',
        useValue: {
          autoLogin: false,
          providers: [
            {
              id: GoogleLoginProvider.PROVIDER_ID,
              provider: new GoogleLoginProvider(
                '594584934584-j070i5bvhdrv8kojs79s4k4tm5ovto9p.apps.googleusercontent.com'
              )
            }
          ]
        } as SocialAuthServiceConfig,
      }
    ],
    bootstrap: [AppComponent]
  })
export class AppModule { }