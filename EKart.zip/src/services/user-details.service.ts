import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';

@Injectable({
  providedIn: 'root'
})
export class UserDetailsService {

  constructor(private http: HttpClient) { }

  getAllUsers()
  {
    return this.http.get('https://localhost:44345/api/EKartHome/GetAllUsers');
  }

  addUser(userName,userEmail)
  {
    let user = {
      userName: userName,
      EmailId:userEmail,
      RoleId:2,
      Phone:9787878798,
      Address:"India",
      Gender:"N",
    }
    return this.http.put('https://localhost:44345/api/EKartHome/AddUser?EmailId='+userEmail,user);
  }
}


