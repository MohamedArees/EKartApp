import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';

@Injectable({
  providedIn: 'root'
})
export class ProductDetailsService {

  constructor(private http: HttpClient) { }

  getAllProducts()
  {
    return this.http.get('https://localhost:44345/api/EKartHome/GetAllProducts');
  }
  addProduct(productObj)
  {
    return this.http.put('https://localhost:44345/api/EKartHome/AddProduct',productObj);
  }

  deleteProduct(productId)
  {
    return this.http.delete('https://localhost:44345/api/EKartHome/DeleteProduct?productId='+productId);
  }
  updateProduct(productObj)
  {
    return this.http.put('https://localhost:44345/api/EKartHome/UpdateProduct',productObj);
  }
  getAllPurchases(emailId)
  {
    return this.http.get('https://localhost:44345/api/EKartHome/GetAllPurchases?emailId='+emailId);
  }

  purchaseProducts(emailId,cart)
  {
    return this.http.put('https://localhost:44345/api/EKartHome/UpdateProduct?emailId='+emailId,cart);
  }
}
